// Не открывать лишнее окно консоли в готовой программе.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
  sportfarm_lib::run();
}
