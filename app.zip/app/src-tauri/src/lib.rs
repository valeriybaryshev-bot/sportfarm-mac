// Sport Farm — программа для ПК (28.09.2026).
// Окно открывает страницу загрузки (dist/index.html): она проверяет, есть ли новая версия программы
// (CEO 02.10: сама не скачивает и не ставит — предлагает скачать в браузере); затем переходит на сайт https://sf.clashofimperia.ru (поддомен на домене Арены) — весь интерфейс там,
// поэтому исправления интерфейса видны сразу, без переустановки.
use tauri::Manager;
use tauri_plugin_updater::UpdaterExt;

#[derive(serde::Serialize)]
struct UpdateInfo { available: bool, version: String, current: String }

#[tauri::command]
async fn sf_update_check(app: tauri::AppHandle) -> Result<UpdateInfo, String> {
  let current = app.package_info().version.to_string();
  let updater = app.updater().map_err(|e| e.to_string())?;
  match updater.check().await.map_err(|e| e.to_string())? {
    Some(u) => Ok(UpdateInfo { available: true, version: u.version.clone(), current }),
    None => Ok(UpdateInfo { available: false, version: String::new(), current }),
  }
}

// CEO 02.10: Касперский удалил Арену — «PDM:Exploit.Win32.Generic.nblk» (поведение: программа сама скачала .exe во
// временную папку и тихо запустила его — так ведут себя взломанные программы). Поэтому Sport Farm больше НЕ скачивает
// и НЕ запускает установщики сама: при новой версии открывает страницу загрузки в браузере человека, установщик
// он запускает сам — обычная установка, как любой программы. Адрес зашит — сайт склада его подменить не может.
const DOWNLOAD_URL: &str = "https://sf.clashofimperia.ru/download";

#[tauri::command]
fn sf_open_download(app: tauri::AppHandle) -> Result<(), String> {
  use tauri_plugin_opener::OpenerExt;
  app.opener().open_url(DOWNLOAD_URL, None::<&str>).map_err(|e| e.to_string())
}

// Владелец 28.09: «чтобы никто не мог через программы получить доступ к ПК пользователя». Окно программы открывает
// только свою страницу загрузки и сайт склада по HTTPS — любой другой адрес (ссылка в чате, подмена) не откроется.
// У сайта нет доступа к командам программы (capabilities — только локальная страница), файлов ПК программа не трогает.
const SITE_HOST: &str = "sf.clashofimperia.ru";
fn allowed(url: &tauri::Url) -> bool {
  match url.scheme() {
    "tauri" | "about" | "blob" | "data" => true,
    "http" => url.host_str() == Some("tauri.localhost"),
    "https" => matches!(url.host_str(), Some(h) if h == SITE_HOST || h == "tauri.localhost"),
    _ => false,
  }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
  let guard = tauri::plugin::Builder::<tauri::Wry>::new("sf-guard")
    .on_navigation(|_webview, url| {
      let ok = allowed(url);
      if !ok { log::warn!("заблокирован переход: {url}"); }
      ok
    })
    .build();
  tauri::Builder::default()
    .plugin(guard)
    .plugin(tauri_plugin_updater::Builder::new().build())
    .plugin(tauri_plugin_opener::init())
    .invoke_handler(tauri::generate_handler![sf_update_check, sf_open_download])
    .setup(|app| {
      if let Some(w) = app.get_webview_window("main") {
        // Владелец 29.09: «в программе для ПК включить сохранение пароля» — WebView2 сам предложит сохранить пароль и
        // подставит его на входе (как Edge). Вход по отпечатку / Windows Hello — ключами доступа на сайте.
        #[cfg(windows)]
        let _ = w.with_webview(|wv| unsafe {
          use webview2_com::Microsoft::Web::WebView2::Win32::ICoreWebView2Settings4;
          use windows_core::Interface;
          if let Ok(core) = wv.controller().CoreWebView2() {
            if let Ok(settings) = core.Settings() {
              if let Ok(s4) = settings.cast::<ICoreWebView2Settings4>() {
                let _ = s4.SetIsPasswordAutosaveEnabled(true);
              }
            }
          }
        });
        let _ = w.show();
        let _ = w.set_focus();
      }
      Ok(())
    })
    .run(tauri::generate_context!())
    .expect("Sport Farm: ошибка запуска");
}
